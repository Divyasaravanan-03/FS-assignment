const router = require("express").Router();
const Borrowing = require("../models/Borrowing");
const Book = require("../models/Book");

router.get("/", async (req, res) => {
  try {
    const borrowings = await Borrowing.find()
      .populate("book_id", "title author")
      .populate("member_id", "name email")
      .sort({ createdAt: -1 });
    res.json(borrowings);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/", async (req, res) => {
  try {
    const book = await Book.findById(req.body.book_id);
    if (!book || book.available_copies < 1)
      return res.status(400).json({ error: "Book not available" });

    const borrowing = await Borrowing.create(req.body);
    book.available_copies -= 1;
    await book.save();
    res.status(201).json(borrowing);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Return a book
router.put("/:id/return", async (req, res) => {
  try {
    const borrowing = await Borrowing.findById(req.params.id);
    if (!borrowing) return res.status(404).json({ error: "Borrowing not found" });
    if (borrowing.status === "returned")
      return res.status(400).json({ error: "Already returned" });

    borrowing.status = "returned";
    borrowing.return_date = new Date();

    // Calculate fine: Rs 5 per day overdue
    const dueDate = new Date(borrowing.due_date);
    const returnDate = new Date();
    if (returnDate > dueDate) {
      const daysLate = Math.ceil((returnDate - dueDate) / 86400000);
      borrowing.fine_amount = daysLate * 5;
    }
    await borrowing.save();

    const book = await Book.findById(borrowing.book_id);
    if (book) {
      book.available_copies += 1;
      await book.save();
    }

    res.json(borrowing);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    await Borrowing.findByIdAndDelete(req.params.id);
    res.json({ message: "Borrowing deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
