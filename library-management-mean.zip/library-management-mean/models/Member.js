const mongoose = require("mongoose");

const memberSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, default: "" },
  address: { type: String, default: "" },
  membership_type: { type: String, default: "standard" },
  is_active: { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model("Member", memberSchema);
