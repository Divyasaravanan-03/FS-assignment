const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  author: { type: String, required: true },
  isbn: { type: String, default: "" },
  category: { type: String, default: "General" },
  total_copies: { type: Number, default: 1 },
  available_copies: { type: Number, default: 1 },
  published_year: { type: Number },
  description: { type: String, default: "" },
}, { timestamps: true });

module.exports = mongoose.model("Book", bookSchema);
