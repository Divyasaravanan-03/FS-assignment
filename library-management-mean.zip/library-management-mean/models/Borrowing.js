const mongoose = require("mongoose");

const borrowingSchema = new mongoose.Schema({
  book_id: { type: mongoose.Schema.Types.ObjectId, ref: "Book", required: true },
  member_id: { type: mongoose.Schema.Types.ObjectId, ref: "Member", required: true },
  borrow_date: { type: Date, default: Date.now },
  due_date: { type: Date, default: () => new Date(Date.now() + 14 * 86400000) },
  return_date: { type: Date, default: null },
  status: { type: String, default: "borrowed" },
  fine_amount: { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model("Borrowing", borrowingSchema);
