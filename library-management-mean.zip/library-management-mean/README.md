# LibraHub - Library Management System (MEAN Stack)

## Tech Stack
- **M**ongoDB — Database
- **E**xpress.js — Backend framework
- **A**ngularJS — Frontend framework
- **N**ode.js — Runtime

## Features
- 📚 **Books** — Add, view, delete books with category & copies tracking
- 👥 **Members** — Manage library members with membership types
- 📋 **Borrowings** — Borrow/return books with automatic fine calculation (₹5/day overdue)
- 📊 **Dashboard** — Overview stats with due date alerts (3-day warning)
- 📈 **Reports** — Category breakdown, overdue books, total fines

## Prerequisites
- [Node.js](https://nodejs.org/) (v16+)
- [MongoDB](https://www.mongodb.com/try/download/community) (running locally on port 27017)

## Setup & Run

```bash
# 1. Extract the zip and enter the folder
cd library-management-mean

# 2. Install dependencies
npm install

# 3. Make sure MongoDB is running
# On Windows: net start MongoDB
# On Mac: brew services start mongodb-community
# On Linux: sudo systemctl start mongod

# 4. Start the server
npm start
# or for auto-reload during development:
npm run dev

# 5. Open in browser
# http://localhost:3000
```

## Project Structure
```
├── server.js          # Express server + MongoDB connection
├── models/
│   ├── Book.js        # Book schema (Mongoose)
│   ├── Member.js      # Member schema
│   └── Borrowing.js   # Borrowing schema with book/member refs
├── routes/
│   ├── books.js       # CRUD API for books
│   ├── members.js     # CRUD API for members
│   └── borrowings.js  # CRUD + return API for borrowings
├── public/
│   └── index.html     # AngularJS SPA (frontend)
├── .env               # Environment variables
└── package.json       # Dependencies
```

## API Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | /api/books | Get all books |
| POST   | /api/books | Add a book |
| PUT    | /api/books/:id | Update a book |
| DELETE | /api/books/:id | Delete a book |
| GET    | /api/members | Get all members |
| POST   | /api/members | Add a member |
| PUT    | /api/members/:id | Update a member |
| DELETE | /api/members/:id | Delete a member |
| GET    | /api/borrowings | Get all borrowings |
| POST   | /api/borrowings | Create borrowing |
| PUT    | /api/borrowings/:id/return | Return a book |
| DELETE | /api/borrowings/:id | Delete borrowing |
